# Pure-CSS3-Menu-Button

![DEMO](img/menu-btn.png)

[DEMO](http://codepen.io/ClearDesign/full/jPLZRp)
